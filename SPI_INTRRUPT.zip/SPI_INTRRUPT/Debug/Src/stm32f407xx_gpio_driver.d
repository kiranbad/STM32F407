Src/stm32f407xx_gpio_driver.o: ../Src/stm32f407xx_gpio_driver.c \
 ../Inc/stm32f407xx_gpio_driver.h ../Inc/stm32f407xx.h \
 ../Inc/stm32f407xx_spi_driver.h
../Inc/stm32f407xx_gpio_driver.h:
../Inc/stm32f407xx.h:
../Inc/stm32f407xx_spi_driver.h:
