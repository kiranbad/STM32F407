################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/spi_int.c \
../Src/stm32f407xx_gpio_driver.c \
../Src/stm32f407xx_spi_driver.c \
../Src/syscalls.c \
../Src/sysmem.c 

OBJS += \
./Src/spi_int.o \
./Src/stm32f407xx_gpio_driver.o \
./Src/stm32f407xx_spi_driver.o \
./Src/syscalls.o \
./Src/sysmem.o 

C_DEPS += \
./Src/spi_int.d \
./Src/stm32f407xx_gpio_driver.d \
./Src/stm32f407xx_spi_driver.d \
./Src/syscalls.d \
./Src/sysmem.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F407G_DISC1 -DSTM32F4 -DSTM32F407VGTx -c -I../Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/spi_int.cyclo ./Src/spi_int.d ./Src/spi_int.o ./Src/spi_int.su ./Src/stm32f407xx_gpio_driver.cyclo ./Src/stm32f407xx_gpio_driver.d ./Src/stm32f407xx_gpio_driver.o ./Src/stm32f407xx_gpio_driver.su ./Src/stm32f407xx_spi_driver.cyclo ./Src/stm32f407xx_spi_driver.d ./Src/stm32f407xx_spi_driver.o ./Src/stm32f407xx_spi_driver.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su

.PHONY: clean-Src

